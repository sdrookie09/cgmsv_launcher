"""
Version information for CGMSV Launcher
"""

__version__ = "1.0.0"
__author__ = "sdrookie09"
__description__ = "CGMSV Launcher - Multi-CGMSV Instance Manager"
__license__ = "MIT"